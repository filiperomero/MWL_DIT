<?php

/* Root Directory For All Files */
define("ROOT_DIR", dirname( dirname(__FILE__) ) );

/* database constants */
define("DB_HOST", "remote-mysql3.servage.net" );	// set database host
define("DB_USER", "filipe" ); 	// set database user
define("DB_PASS", "XZmPj4PAd42FzXdF" ); 		// set database password
define("DB_PORT", 3306);					// set database port
define("DB_NAME", "filipe" );		// set database name
define("DB_CHARSET", "utf8" ); 				// set database charset
define("DB_DEBUGMODE", true ); 				// set database charset


?>